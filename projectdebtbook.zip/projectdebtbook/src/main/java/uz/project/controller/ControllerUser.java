package uz.project.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.project.apiResponse.ApiResponse;
import uz.project.jwt.JwtProvider;
import uz.project.payload.LoginDTO;
import uz.project.payload.UserDTO;
import uz.project.model.entity.user.User;
import uz.project.service.UserService;
@RestController
@RequestMapping("/api")
public class ControllerUser {
    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final JwtProvider jwtProvider;
    @Autowired
    public ControllerUser(UserService userService, AuthenticationManager authenticationManager, JwtProvider jwtProvider) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.jwtProvider = jwtProvider;
    }
    @PostMapping("/register")
    public HttpEntity<?> register(
            @RequestBody UserDTO userDTO)
    {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.addUser(userDTO));
    }
    @PostMapping("/login")
    public HttpEntity<?> login(
            @RequestBody LoginDTO loginDTO
    ) {
        return ResponseEntity.ok(userService.login(loginDTO
        ));
    }
}
