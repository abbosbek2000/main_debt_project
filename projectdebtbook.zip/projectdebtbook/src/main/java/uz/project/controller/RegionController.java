package uz.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import uz.project.apiResponse.ApiResponse;
import uz.project.model.entity.region.Region;
import uz.project.model.entity.response.BaseResponse;
import uz.project.service.RegionService;
import java.util.List;

@RestController
@RequestMapping("/api/region")
public class RegionController {
    @Autowired
    RegionService regionService;
//    @PreAuthorize("hasAuthority('ADMIN') ")
    @PostMapping("/add")
    public HttpEntity<?> addRegion(
            @RequestBody Region region)
    {
        return ResponseEntity.ok(regionService.addRegion(region));
    }

    @GetMapping("/list")
    public List<Region> getRegionList() {
        return regionService.getRegionList();
    }
}
