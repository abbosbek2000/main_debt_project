package uz.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import uz.project.controller.base.BaseController;
import uz.project.model.entity.city.City;
import uz.project.model.entity.response.BaseResponse;
import uz.project.payload.CityDto;
import uz.project.repository.CityRepository;
import uz.project.repository.RegionRepository;
import uz.project.service.BaseService;
import uz.project.service.CityService;

import java.util.List;


@RestController

@RequestMapping("/api/city")
public class CityController implements BaseService {
    private final CityRepository cityRepository;
    private final RegionRepository regionRepository;

    @Autowired
    public CityController(CityRepository cityRepository, RegionRepository regionRepository) {
        this.cityRepository = cityRepository;
        this.regionRepository = regionRepository;
    }

    @Autowired
    CityService cityService;
    @PostMapping("/add")
    public ResponseEntity<?> addCity(
            @RequestBody CityDto cityDto)
    {
        return ResponseEntity.ok(cityService.addCity(cityDto));
    }

    @GetMapping("/list")
    public List<City> getCityList() {
        return cityRepository.findAll();
    }

}
