package uz.project.enums;

public enum RoleEnum {
   USER,ADMIN,SUPER_ADMIN
}
