package uz.project.payload;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import uz.project.enums.RoleEnum;

@Data
public class  UserDTO {
    private String username;

    private String password;

    private String fullName;

    @JsonProperty("user_role")
    private RoleEnum roleEnum;

    

}
