package uz.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.project.model.entity.role.RoleEntity;
import uz.project.model.entity.role.RoleEnum;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends JpaRepository<RoleEntity, Integer> {
    Optional<RoleEntity> findByRoleName(RoleEnum roleName);
}
