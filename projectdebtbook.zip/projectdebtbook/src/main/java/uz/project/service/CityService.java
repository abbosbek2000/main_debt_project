package uz.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.project.apiResponse.ApiResponse;
import uz.project.model.entity.city.City;
import uz.project.model.entity.region.Region;
import uz.project.payload.CityDto;
import uz.project.repository.CityRepository;
import uz.project.repository.RegionRepository;

import java.util.Optional;

@Service
public class CityService implements BaseService {
    private final CityRepository cityRepository;
    private final RegionRepository regionRepository;

    @Autowired
    public CityService(CityRepository cityRepository, RegionRepository regionRepository) {
        this.cityRepository = cityRepository;
        this.regionRepository = regionRepository;
    }

    public ApiResponse addCity(CityDto cityDto) {
        try {
            City city = new City();
            city.setName(cityDto.getName());
            Optional<Region> optionalRegion = regionRepository.findById(cityDto.getRegion_id());
            if (optionalRegion.isPresent()) {
                Region region = optionalRegion.get();
                city.setRegion(region);
                cityRepository.save(city);
                return CREATED_CITY;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return NO_CREATED_CITY;
    }
}
