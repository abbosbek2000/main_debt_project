package uz.project.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.project.apiResponse.ApiResponse;
import uz.project.jwt.JwtProvider;
import uz.project.model.entity.role.RoleEnum;
import uz.project.model.entity.user.User;
import uz.project.payload.LoginDTO;
import uz.project.payload.UserDTO;
import uz.project.repository.RoleRepository;
import uz.project.repository.UserRepository;
import java.util.Collections;
import java.util.Optional;
@Service
public class
UserService implements BaseService{
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final RoleRepository roleRepository;
    private final JwtProvider jwtProvider;
    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, RoleRepository roleRepository, JwtProvider jwtProvider) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.roleRepository = roleRepository;
        this.jwtProvider = jwtProvider;
    }

    public ApiResponse addUser(
            UserDTO userDTO
    ) {
        boolean exists = userRepository.existsByUsername(userDTO.getUsername());
        if (exists)
        return USER_EXIST;
        User user = new User();
        user.setUsername(userDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));

        if (userDTO.getRoleEnum() == null)
            user.setRoles(Collections.singletonList(roleRepository.findByRoleEnum(RoleEnum.USER)));
        else
            user.setRoles(Collections.singletonList(roleRepository.findByRoleEnum(RoleEnum.ADMIN)));
        userRepository.save(user);

        return SUCCESS;
    }

    public ApiResponse login(
            LoginDTO loginDTO
    ) {
        boolean exists = userRepository.existsByUsername(loginDTO.getUsername());
        if (!exists)
            return USER_EXIST;
        String token = jwtProvider.generateToken(loginDTO.getUsername());
        SUCCESS.setData(token);
        return SUCCESS;



    }
}
