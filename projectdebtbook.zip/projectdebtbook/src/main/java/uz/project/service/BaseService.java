package uz.project.service;

import uz.project.apiResponse.ApiResponse;

public interface BaseService {
    ApiResponse SUCCESS = new ApiResponse("muvaffaqiyatili bajarildi", true, 0);

    ApiResponse USER_EXIST = new ApiResponse("bu username allaqachon mavjud", false, -100);

    ApiResponse USER_NOT_FOUND = new ApiResponse("bu user topilmadi", false, -101);

    ApiResponse CREATED_REGION = new ApiResponse("region muvaffaqiyatli qo'shildi", true, 100);

    ApiResponse NO_CREATED_REGION = new ApiResponse("region qo'shilmadi", false, -101);

    ApiResponse CREATED_CITY = new ApiResponse("city muvaffaqiyatli qo'shildi", true, 100);

    ApiResponse NO_CREATED_CITY = new ApiResponse("city qo'shilmadi", false, -101);

    ApiResponse CREATED_DEBT_USER = new ApiResponse("debt user muvaffaqiyatli qo'shildi", true, 100);

    ApiResponse NO_CREATED_DEBT_USER = new ApiResponse("debt user qo'shilmadi", true, 100);





}
