package uz.project.utils;

public interface AppConstants {
    String USER = "User";

    String ADMIN = "Admin";
}
