package uz.project.model.entity.role;

public enum RoleEnum {
    SUPER_ADMIN,
    ADMIN,
    USER
}
