insert into role_entity(id, role_enum) values (10,'ADMIN');
insert into role_entity(id, role_enum) values (20,'SUPER_ADMIN');
insert into role_entity(id, role_enum) values (30, 'USER');