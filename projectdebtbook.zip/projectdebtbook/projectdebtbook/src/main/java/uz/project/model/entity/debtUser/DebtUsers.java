package uz.project.model.entity.debtUser;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.project.model.entity.base.BaseModel;
import uz.project.model.entity.city.City;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class DebtUsers extends BaseModel {
    @ManyToOne
    @JoinColumn(name = "city_id")
    private City city;
    private Double debtAmount;
    private Integer limitMonth;
    @Column(unique = true)
    private String phoneNumber;






}
