package uz.project.register;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User extends BaseRegister implements UserDetails {
    private String username;
    @Column(unique = true,nullable = false)
    private String phoneNumber;
    @NotNull(message = "Password can not be null")
    private String password;

    private String prePassword;


    private boolean enabled;
    private boolean accountNonExpired = true;
    private boolean accountNonLocked = true;
    private boolean credentialsNonExpired = true;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();

        return grantedAuthorities;
    }

    public User(String username, String phoneNumber, String password,boolean enabled) {
        this.username = username;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.enabled = enabled;
    }
}
