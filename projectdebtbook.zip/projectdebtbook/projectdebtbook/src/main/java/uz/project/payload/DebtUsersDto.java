package uz.project.payload;


import lombok.Data;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Data

public class DebtUsersDto {
    @NotNull(message = "name null bo'lishi mumkin emas")
    private String name;
    @NotNull(message = "debtAmount null bo'lishi mumkin emas")
    private Double debtAmount;
    @NotNull(message = "limitMonth null bo'lishi mumkin emas")
    private Integer limitMonth;
    @NotNull(message = "null bo'lishi mumkin emas")
    @Column(unique = true)
    private String phoneNumber;
    private UUID city_id;



}
