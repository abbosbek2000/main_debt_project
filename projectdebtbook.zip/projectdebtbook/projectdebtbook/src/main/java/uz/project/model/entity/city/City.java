package uz.project.model.entity.city;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import uz.project.model.entity.base.BaseModel;
import uz.project.model.entity.debtUser.DebtUsers;
import uz.project.model.entity.region.Region;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class City extends BaseModel {

    @ManyToOne
    @JoinColumn(name = "region_id")
    private Region region;
    @JsonIgnore
    @OneToMany(mappedBy = "city")
    private List<DebtUsers> debtUsersList;
}
