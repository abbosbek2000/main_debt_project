package uz.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.project.controller.base.BaseController;
import uz.project.model.entity.region.Region;
import uz.project.model.entity.response.BaseResponse;
import uz.project.repository.RegionRepository;

import java.util.List;

@Service
public class RegionService implements BaseController {
    @Autowired
    RegionRepository regionRepository;

    public BaseResponse addRegion(Region region) {
        try {
            regionRepository.save(region);
            return SUCCESS;

        } catch (Exception e) {
            return ERROR;
        }
    }
    public List<Region> getRegionList() {
        List<Region> regions = regionRepository.findAll();
        return regions;
    }
}
