package uz.project.model.entity.region;

import lombok.Data;
import uz.project.model.entity.base.BaseModel;

import javax.persistence.Entity;

@Entity
@Data

public class Region extends BaseModel {

}
