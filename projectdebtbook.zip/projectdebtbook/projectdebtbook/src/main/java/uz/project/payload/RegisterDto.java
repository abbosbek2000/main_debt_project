package uz.project.payload;

import lombok.Data;

@Data
public class RegisterDto {
}
