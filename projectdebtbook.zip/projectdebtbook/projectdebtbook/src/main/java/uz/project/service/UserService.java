package uz.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import uz.project.apiResponse.ApiResponse;
import uz.project.payload.UserDTO;
import uz.project.register.User;
import uz.project.repository.UserRepository;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public ApiResponse addUser(UserDTO userDTO) {
        if (!userDTO.getPassword().equals(userDTO.getPrePassword()))
            return new ApiResponse("parollar mos emas", false);
        if (userRepository.existsByUsername(userDTO.getUsername()))
            return new ApiResponse("Bunday username li user ro'yxatdan o'tgan", false);

        User user = new User();
        user.setUsername(userDTO.getUsername());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        user.setPhoneNumber(userDTO.getPhoneNumber());
        user.setEnabled(true);
        userRepository.save(user);
        return new ApiResponse("Muvaffaqiyatli saqlandi", true);

    }
}
