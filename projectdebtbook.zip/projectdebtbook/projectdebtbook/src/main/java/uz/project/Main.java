package uz.project;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        long expireDate = 36_000_000;

        Date expireTime = new Date(expireDate + System.currentTimeMillis());
        System.out.println(expireTime);
    }
}
