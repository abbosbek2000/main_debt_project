package uz.project.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.project.apiResponse.ApiResponse;
import uz.project.jwt.JwtProvider;
import uz.project.payload.LoginDTO;
import uz.project.payload.UserDTO;
import uz.project.register.User;
import uz.project.service.UserService;
@RestController
@RequestMapping("/api")
public class ControllerUser {
    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final JwtProvider jwtProvider;
    @Autowired
    public ControllerUser(UserService userService, AuthenticationManager authenticationManager, JwtProvider jwtProvider) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.jwtProvider = jwtProvider;
    }
    @PostMapping("/register")
    public HttpEntity<?> register(
            @RequestBody UserDTO userDTO)
    {
        ApiResponse apiResponse = userService.addUser(userDTO);
        if (apiResponse.isSuccess())
            return ResponseEntity.status(HttpStatus.OK).body("SUCCESS");
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("ERROR");
    }

    @PostMapping("/login")
    public HttpEntity<?> login(
            @RequestBody LoginDTO loginDTO
    ) {
        Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                loginDTO.getUsername(), loginDTO.getPassword()
        ));
        User user = (User) authenticate.getPrincipal();
        String token = jwtProvider.generateToken(user.getUsername());
        return ResponseEntity.ok(token);
    }
}
