package uz.project.payload;

import lombok.Data;

import java.util.UUID;

@Data
public class CityDto {
    private String name;
    private UUID region_id;

}
