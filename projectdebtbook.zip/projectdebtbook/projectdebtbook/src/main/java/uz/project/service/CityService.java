package uz.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import uz.project.controller.base.BaseController;
import uz.project.model.entity.city.City;
import uz.project.model.entity.region.Region;
import uz.project.model.entity.response.BaseResponse;
import uz.project.payload.CityDto;
import uz.project.repository.CityRepository;
import uz.project.repository.RegionRepository;

import java.util.Optional;

@Service
public class CityService implements BaseController {
    private final CityRepository cityRepository;
    private final RegionRepository regionRepository;

    @Autowired
    public CityService(CityRepository cityRepository, RegionRepository regionRepository) {
        this.cityRepository = cityRepository;
        this.regionRepository = regionRepository;
    }

    public BaseResponse addCity(CityDto cityDto) {
        City city = new City();
        city.setName(cityDto.getName());
        Optional<Region> optionalRegion = regionRepository.findById(cityDto.getRegion_id());
        if (optionalRegion.isPresent()) {
            Region region = optionalRegion.get();
            city.setRegion(region);
            cityRepository.save(city);
            return SUCCESS;
        }
        return ERROR;
    }
}
